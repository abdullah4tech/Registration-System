<template>
  <div>
    <router-view />
  </div>
</template>

<script>

// Not needed 
//import SignUp from './components/SignUp.vue';

export default {
  name: 'App',
  components: {}
}
</script>

<style>

</style>
